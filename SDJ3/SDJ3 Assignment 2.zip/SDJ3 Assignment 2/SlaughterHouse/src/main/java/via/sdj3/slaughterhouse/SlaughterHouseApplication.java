package via.sdj3.slaughterhouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlaughterHouseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SlaughterHouseApplication.class, args);
    }

}
