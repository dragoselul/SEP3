package via.sdj3.slaughterhouse;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest()
class SlaughterHouseApplicationTests {


}
